GameSellSpot-main/
├── client/
│   ├── src/
│   │   ├── index.tsx
│   │   └── ... (other React components)
│   ├── index.html
│   └── ... (other client files)
├── shared/
│   └── schema.ts
├── server/
│   ├── index.ts
│   └── ... (other server files)
├── dist/
├── migrations/
├── .replit
├── components.json
├── drizzel.config.ts
├── package.json
├── package-lock.json
├── postcss.config.js
├── README.md
└── tailwind.config.ts