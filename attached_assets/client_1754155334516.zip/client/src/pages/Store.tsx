GameSellSpot-main/
├── client/
│   ├── src/
│   │   ├── index.tsx
│   │   └── ... (other source files)
│   ├── index.html
│   └── ... (other client files)
├── shared/
│   ├── schema.ts
│   └── ... (other shared files)
├── server/
│   ├── index.ts
│   └── ... (other server files)
├── dist/
├── node_modules/
├── .replit
├── components.json
├── drizzel.config.ts
├── package.json
├── package-lock.json
├── postcss.config.js
├── README.md
└── tailwind.config.ts