GameSellSpot-main/
├── client/
│   ├── src/
│   │   ├── components/
│   │   ├── hooks/
│   │   ├── lib/
│   │   ├── pages/
│   │   ├── App.tsx
│   │   └── index.tsx
│   ├── index.html
│   └── ...
├── shared/
│   ├── schema.ts
│   └── ...
├── server/
│   ├── index.ts
│   └── ...
├── .replit
├── components.json
├── drizzel.config.ts
├── package.json
├── package-lock.json
├── postcss.config.js
├── README.md
└── tailwind.config.ts