GameSellSpot-main/
├── client/
│   ├── src/
│   │   ├── index.tsx
│   │   ├── App.tsx
│   │   └── components/
│   ├── index.html
│   └── ...
├── shared/
│   ├── schema.ts
│   └── ...
├── server/
│   ├── index.ts
│   └── ...
├── dist/
├── migrations/
├── .replit
├── components.json
├── drizzle.config.ts
├── package.json
├── package-lock.json
├── postcss.config.js
├── README.md
└── tailwind.config.ts