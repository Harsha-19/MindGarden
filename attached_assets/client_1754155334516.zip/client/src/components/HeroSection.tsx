GameSellSpot-main/
├── client/
│   ├── src/
│   │   ├── components/
│   │   ├── hooks/
│   │   ├── lib/
│   │   ├── pages/
│   │   ├── index.tsx
│   │   └── App.tsx
│   ├── index.html
│   └── styles/
│       └── index.css
├── shared/
│   └── schema.ts
├── server/
│   └── index.ts
├── .replit
├── components.json
├── drizzel.config.ts
├── package.json
├── package-lock.json
├── postcss.config.js
├── README.md
└── tailwind.config.ts